<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = '6XxbadjulDKCZGOm6fcxFu6IQ8bH5ZA9localhost';
$CFG->bootstraphash = '5d246358791a4e200eaedb6dc008a359';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
