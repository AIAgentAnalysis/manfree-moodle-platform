The file stringnames.txt contains a list of all the strings used during the install process.

A daily cron job will pick up the changes to this file and update all the language files
(ie those in install/lang/*/install.php) automatically.


Martin Dougiamas, 20/8/2007
