ogv.js 1.9.0
--------------
https://github.com/bvibber/ogv.js

Instructions to import ogv.js library into Moodle:

1. Download the latest release from https://github.com/bvibber/ogv.js/releases
   (do not choose "Source code")
2. copy 'ogv-es2017.js' into 'amd/src/local/ogv/ogv.js'.
3. copy all files into 'ogvjs/' folder.
